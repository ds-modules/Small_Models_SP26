--- COURSE SUMMARY ---

- week: 1
  slides:
  - file: Lecture 1 - Introduction and Overview.md
    title: Lecture 1 - Introduction and Overview
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 1
      - Introduction and Overview.pptx
    week: 1
    order: 1
  notebooks:
  - file: lec01/lec01.md
    title: lec01
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec01/lec01.ipynb
  textbook:
    chapters:
    - 0
    files:
    - file: 00-intro/index.md
      title: index
      source_path: content/00-intro/index.ipynb
      type: textbook
      order: 1
- week: 2
  slides:
  - file: Lecture 2 - Demand.md
    title: Lecture 2 - Demand
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 2
      - Demand.pptx
    week: 2
    order: 2
  notebooks:
  - file: lec02/Avocados_demand.md
    title: Avocados_demand
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec02/Avocados_demand.ipynb
  - file: lec02/demand-curve-Fa24.md
    title: demand-curve-Fa24
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec02/demand-curve-Fa24.ipynb
  - file: lec02/Demand_Steps_24.md
    title: Demand_Steps_24
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec02/Demand_Steps_24.ipynb
  - file: lec02/PriceElasticity.md
    title: PriceElasticity
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec02/PriceElasticity.ipynb
  - file: lec02/ScannerData_Beer.md
    title: ScannerData_Beer
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec02/ScannerData_Beer.ipynb
  textbook:
    chapters:
    - 1
    files:
    - file: 01-demand/index.md
      title: index
      source_path: content/01-demand/index.md
      type: textbook
      order: 1
    - file: 01-demand/01-demand.md
      title: 01-demand
      source_path: content/01-demand/01-demand.ipynb
      type: textbook
      order: 2
    - file: 01-demand/02-example.md
      title: 02-example
      source_path: content/01-demand/02-example.ipynb
      type: textbook
      order: 3
    - file: 01-demand/03-log-log.md
      title: 03-log-log
      source_path: content/01-demand/03-log-log.ipynb
      type: textbook
      order: 4
    - file: 01-demand/04-elasticity.md
      title: 04-elasticity
      source_path: content/01-demand/04-elasticity.ipynb
      type: textbook
      order: 5
- week: 3
  slides:
  - file: Lecture 3 - Supply.md
    title: Lecture 3 - Supply
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 3
      - Supply.pptx
    week: 3
    order: 3
  notebooks:
  - file: lec03/3.0-CubicCostCurve.md
    title: 3.0-CubicCostCurve
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec03/3.0-CubicCostCurve.ipynb
  - file: lec03/3.1-Supply.md
    title: 3.1-Supply
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec03/3.1-Supply.ipynb
  - file: lec03/3.2-sympy.md
    title: 3.2-sympy
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec03/3.2-sympy.ipynb
  - file: lec03/3.3a-california-energy.md
    title: 3.3a-california-energy
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec03/3.3a-california-energy.ipynb
  - file: lec03/3.3b-a-really-hot-tuesday.md
    title: 3.3b-a-really-hot-tuesday
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec03/3.3b-a-really-hot-tuesday.ipynb
  textbook:
    chapters:
    - 2
    files:
    - file: 02-supply/index.md
      title: index
      source_path: content/02-supply/index.md
      type: textbook
      order: 1
    - file: 02-supply/01-supply.md
      title: 01-supply
      source_path: content/02-supply/01-supply.ipynb
      type: textbook
      order: 2
    - file: 02-supply/02-eep147-example.md
      title: 02-eep147-example
      source_path: content/02-supply/02-eep147-example.ipynb
      type: textbook
      order: 3
    - file: 02-supply/03-sympy.md
      title: 03-sympy
      source_path: content/02-supply/03-sympy.ipynb
      type: textbook
      order: 4
    - file: 02-supply/04-market-equilibria.md
      title: 04-market-equilibria
      source_path: content/02-supply/04-market-equilibria.ipynb
      type: textbook
      order: 5
- week: 4
  slides:
  - file: ' Lecture 4 - Public.md'
    title: ' Lecture 4 - Public'
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/ Lecture
      4 - Public.pptx
    week: 4
    order: 4
  notebooks:
  - file: lec04/lec04-CSfromSurvey.md
    title: lec04-CSfromSurvey
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec04/lec04-CSfromSurvey.ipynb
  - file: lec04/lec04-CSfromSurvey-closed.md
    title: lec04-CSfromSurvey-closed
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec04/lec04-CSfromSurvey-closed.ipynb
  - file: lec04/lec04-four-plot.md
    title: lec04-four-plot
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec04/lec04-four-plot.ipynb
  - file: lec04/lec04-four-plot-24.md
    title: lec04-four-plot-24
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec04/lec04-four-plot-24.ipynb
  - file: lec04/lec04-Supply-Demand.md
    title: lec04-Supply-Demand
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec04/lec04-Supply-Demand.ipynb
  - file: lec04/lec04-Supply-Demand-closed.md
    title: lec04-Supply-Demand-closed
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec04/lec04-Supply-Demand-closed.ipynb
  textbook:
    chapters:
    - 3
    files:
    - file: 03-public/index.md
      title: index
      source_path: content/03-public/index.md
      type: textbook
      order: 1
    - file: 03-public/govt-intervention.md
      title: govt-intervention
      source_path: content/03-public/govt-intervention.ipynb
      type: textbook
      order: 2
    - file: 03-public/surplus.md
      title: surplus
      source_path: content/03-public/surplus.ipynb
      type: textbook
      order: 4
    - file: 03-public/taxes-subsidies.md
      title: taxes-subsidies
      source_path: content/03-public/taxes-subsidies.ipynb
      type: textbook
      order: 6
- week: 5
  slides:
  - file: Lecture 5 - Production C-D.md
    title: Lecture 5 - Production C-D
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 5
      - Production C-D.pptx
    week: 5
    order: 5
  notebooks:
  - file: lec05/Lec5-Cobb-Douglas.md
    title: Lec5-Cobb-Douglas
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec05/Lec5-Cobb-Douglas.ipynb
  - file: lec05/Lec5-CobbD-AER1928.md
    title: Lec5-CobbD-AER1928
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec05/Lec5-CobbD-AER1928.ipynb
  textbook:
    chapters:
    - 4
    files:
    - file: 04-production/index.md
      title: index
      source_path: content/04-production/index.md
      type: textbook
      order: 1
    - file: 04-production/production.md
      title: production
      source_path: content/04-production/production.ipynb
      type: textbook
      order: 2
    - file: 04-production/shifts.md
      title: shifts
      source_path: content/04-production/shifts.ipynb
      type: textbook
      order: 3
- week: 6
  slides:
  - file: Lecture 6 - Utility and Latex.md
    title: Lecture 6 - Utility and Latex
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 6
      - Utility and Latex.pptx
    week: 6
    order: 6
  notebooks:
  - file: lec06/6.1-Sympy-Differentiation.md
    title: 6.1-Sympy-Differentiation
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec06/6.1-Sympy-Differentiation.ipynb
  - file: lec06/6.2-3D-utility.md
    title: 6.2-3D-utility
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec06/6.2-3D-utility.ipynb
  - file: lec06/6.3-QuantEcon-Optimization.md
    title: 6.3-QuantEcon-Optimization
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec06/6.3-QuantEcon-Optimization.ipynb
  - file: lec06/6.4-latex.md
    title: 6.4-latex
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec06/6.4-latex.ipynb
  - file: lec06/6.5-Edgeworth.md
    title: 6.5-Edgeworth
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec06/6.5-Edgeworth.ipynb
  textbook:
    chapters:
    - 5
    files:
    - file: 05-utility/index.md
      title: index
      source_path: content/05-utility/index.md
      type: textbook
      order: 1
    - file: 05-utility/budget-constraints.md
      title: budget-constraints
      source_path: content/05-utility/budget-constraints.ipynb
      type: textbook
      order: 2
    - file: 05-utility/utility.md
      title: utility
      source_path: content/05-utility/utility.ipynb
      type: textbook
      order: 3
- week: 7
  slides:
  - file: Lecture 7 - Inequality.md
    title: Lecture 7 - Inequality
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 7
      - Inequality.pptx
    week: 7
    order: 7
  notebooks:
  - file: lec07/7.1-inequality.md
    title: 7.1-inequality
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec07/7.1-inequality.ipynb
  - file: lec07/7.2-historical-inequality.md
    title: 7.2-historical-inequality
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec07/7.2-historical-inequality.ipynb
  textbook:
    chapters:
    - 6
    files:
    - file: 06-inequality/index.md
      title: index
      source_path: content/06-inequality/index.md
      type: textbook
      order: 1
    - file: 06-inequality/historical-inequality.md
      title: historical-inequality
      source_path: content/06-inequality/historical-inequality.ipynb
      type: textbook
      order: 2
    - file: 06-inequality/inequality.md
      title: inequality
      source_path: content/06-inequality/inequality.ipynb
      type: textbook
      order: 4
- week: 8
  slides:
  - file: Lecture 8  - Macroeconomics.md
    title: Lecture 8  - Macroeconomics
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 8  -
      Macroeconomics.pptx
    week: 8
    order: 8
  - file: Lecture 8 - Macro.md
    title: Lecture 8 - Macro
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 8
      - Macro.pptx
    week: 8
    order: 9
  notebooks:
  - file: lec08/macro-fred-api.md
    title: macro-fred-api
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec08/macro-fred-api.ipynb
  textbook:
    chapters:
    - 9
    files:
    - file: 09-macro/index.md
      title: index
      source_path: content/09-macro/index.md
      type: textbook
      order: 1
    - file: 09-macro/CentralBanks.md
      title: CentralBanks
      source_path: content/09-macro/CentralBanks.ipynb
      type: textbook
      order: 2
    - file: 09-macro/fiscal_policy.md
      title: fiscal_policy
      source_path: content/09-macro/fiscal_policy.ipynb
      type: textbook
      order: 4
    - file: 09-macro/Indicators.md
      title: Indicators
      source_path: content/09-macro/Indicators.ipynb
      type: textbook
      order: 7
    - file: 09-macro/is_curve.md
      title: is_curve
      source_path: content/09-macro/is_curve.ipynb
      type: textbook
      order: 9
    - file: 09-macro/phillips_curve.md
      title: phillips_curve
      source_path: content/09-macro/phillips_curve.ipynb
      type: textbook
      order: 11
- week: 9
  slides:
  - file: Lecture 9 - Game Theory_.md
    title: Lecture 9 - Game Theory 
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 9
      - Game Theory_.pptx
    week: 9
    order: 10
  notebooks:
  - file: lec09/lecNB-prisoners-dilemma.md
    title: lecNB-prisoners-dilemma
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec09/lecNB-prisoners-dilemma.ipynb
  textbook:
    chapters:
    - 7
    files:
    - file: 07-game-theory/index.md
      title: index
      source_path: content/07-game-theory/index.md
      type: textbook
      order: 1
    - file: 07-game-theory/bertrand.md
      title: bertrand
      source_path: content/07-game-theory/bertrand.ipynb
      type: textbook
      order: 2
    - file: 07-game-theory/cournot.md
      title: cournot
      source_path: content/07-game-theory/cournot.ipynb
      type: textbook
      order: 3
    - file: 07-game-theory/equilibria-oligopolies.md
      title: equilibria-oligopolies
      source_path: content/07-game-theory/equilibria-oligopolies.ipynb
      type: textbook
      order: 5
    - file: 07-game-theory/expected-utility.md
      title: expected-utility
      source_path: content/07-game-theory/expected-utility.ipynb
      type: textbook
      order: 7
    - file: 07-game-theory/python-classes.md
      title: python-classes
      source_path: content/07-game-theory/python-classes.ipynb
      type: textbook
      order: 10
- week: 10
  slides:
  - file: Lecture 10 - Development_.md
    title: Lecture 10 - Development 
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 10
      - Development_.pptx
    week: 10
    order: 11
  notebooks:
  - file: lec10/lec10.1-mapping.md
    title: lec10.1-mapping
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec10/lec10.1-mapping.ipynb
  - file: lec10/Lec10.2-waterguard.md
    title: Lec10.2-waterguard
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec10/Lec10.2-waterguard.ipynb
  textbook:
    chapters:
    - 8
    files:
    - file: 08-development/index.md
      title: index
      source_path: content/08-development/index.md
      type: textbook
      order: 1
- week: 11
  slides:
  - file: Lecture 11 - Econometrics.md
    title: Lecture 11 - Econometrics
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 11
      - Econometrics.pptx
    week: 11
    order: 12
  notebooks:
  - file: lec11/11.1-slr.md
    title: 11.1-slr
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec11/11.1-slr.ipynb
  - file: lec11/11.2-mlr.md
    title: 11.2-mlr
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec11/11.2-mlr.ipynb
  textbook:
    chapters:
    - 11
    files:
    - file: 11-econometrics/index.md
      title: index
      source_path: content/11-econometrics/index.md
      type: textbook
      order: 1
    - file: 11-econometrics/multivariable.md
      title: multivariable
      source_path: content/11-econometrics/multivariable.ipynb
      type: textbook
      order: 2
    - file: 11-econometrics/reading-econ-papers.md
      title: reading-econ-papers
      source_path: content/11-econometrics/reading-econ-papers.ipynb
      type: textbook
      order: 4
    - file: 11-econometrics/single-variable.md
      title: single-variable
      source_path: content/11-econometrics/single-variable.ipynb
      type: textbook
      order: 6
    - file: 11-econometrics/statsmodels.md
      title: statsmodels
      source_path: content/11-econometrics/statsmodels.ipynb
      type: textbook
      order: 8
- week: 12
  slides:
  - file: Lecture 12 - Finance.md
    title: Lecture 12 - Finance
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 12
      - Finance.pptx
    week: 12
    order: 13
  notebooks:
  - file: lec12/lec12-1_Interest_Payments.md
    title: lec12-1_Interest_Payments
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec12/lec12-1_Interest_Payments.ipynb
  - file: lec12/lec12-2-stocks-options.md
    title: lec12-2-stocks-options
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec12/lec12-2-stocks-options.ipynb
  - file: lec12/Lec12-4-PersonalFinance.md
    title: Lec12-4-PersonalFinance
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec12/Lec12-4-PersonalFinance.ipynb
  textbook:
    chapters:
    - 10
    files:
    - file: 10-finance/index.md
      title: index
      source_path: content/10-finance/index.md
      type: textbook
      order: 1
    - file: 10-finance/options.md
      title: options
      source_path: content/10-finance/options.ipynb
      type: textbook
      order: 2
    - file: 10-finance/value-interest.md
      title: value-interest
      source_path: content/10-finance/value-interest.ipynb
      type: textbook
      order: 4
- week: 13
  slides:
  - file: Lecture 13 - Environmental Economics.md
    title: Lecture 13 - Environmental Economics
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 13
      - Environmental Economics.pptx
    week: 13
    order: 14
  notebooks:
  - file: lec13/Co2_ClimateChange.md
    title: Co2_ClimateChange
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec13/Co2_ClimateChange.ipynb
  - file: lec13/ConstructingMAC.md
    title: ConstructingMAC
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec13/ConstructingMAC.ipynb
  - file: lec13/EmissionsTracker.md
    title: EmissionsTracker
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec13/EmissionsTracker.ipynb
  - file: lec13/KuznetsHypothesis.md
    title: KuznetsHypothesis
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec13/KuznetsHypothesis.ipynb
  - file: lec13/RoslingPlots.md
    title: RoslingPlots
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec13/RoslingPlots.ipynb
  textbook:
    chapters:
    - 12
    files:
    - file: 12-environmental/index.md
      title: index
      source_path: content/12-environmental/index.md
      type: textbook
      order: 1
    - file: 12-environmental/KuznetsHypothesis.md
      title: KuznetsHypothesis
      source_path: content/12-environmental/KuznetsHypothesis.ipynb
      type: textbook
      order: 3
    - file: 12-environmental/KuznetsHypothesis-Copy1.md
      title: KuznetsHypothesis-Copy1
      source_path: content/12-environmental/KuznetsHypothesis-Copy1.ipynb
      type: textbook
      order: 4
    - file: 12-environmental/MAC.md
      title: MAC
      source_path: content/12-environmental/MAC.ipynb
      type: textbook
      order: 6
- week: 15
  slides:
  - file: Lecture 15 - Conclusion.md
    title: Lecture 15 - Conclusion
    type: slides
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24LS/Lecture 15
      - Conclusion.pptx
    week: 15
    order: 15
  notebooks:
  - file: lec15/vibecession.md
    title: vibecession
    type: lecture-notebook
    source_path: /Users/ericvandusen/Documents/Data88E-ForTraining/F24Lec_NBs/lec15/vibecession.ipynb
